# benchmark-tools

Benchmark-tools provides commands to ease the development of benchmark charms.

    #!/bin/bash

    benchmark-start || true

    ... (your code goes here) ...

    benchmark-finish || true

# Usage

    $ python setup.py develop
